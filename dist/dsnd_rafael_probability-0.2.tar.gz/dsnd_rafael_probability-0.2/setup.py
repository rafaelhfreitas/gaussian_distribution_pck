from setuptools import setup


setup(name='dsnd_rafael_probability',
      version='0.2',
      description='Gaussian and Binomial distributions',
      package=['dsnd_rafael_probability'],
      author='Rafael Freitas',
      author_email='oraffaudi@gmail.com',
      zip_safe=False
      )
